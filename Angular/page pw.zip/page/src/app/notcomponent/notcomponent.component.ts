import { Component } from '@angular/core';

@Component({
  selector: 'app-notcomponent',
  templateUrl: './notcomponent.component.html',
  styleUrl: './notcomponent.component.css'
})
export class NotcomponentComponent {

}
